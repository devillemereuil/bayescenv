/********************************************************************************
** Form generated from reading UI file 'gui.ui'
**
** Created by: Qt User Interface Compiler version 5.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUI_H
#define UI_GUI_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GUI
{
public:
    QTextBrowser *displayBox;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *startButton;
    QPushButton *stopButton;
    QGroupBox *groupBox_2;
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QCheckBox *SNPmatrixCheckBox;
    QCheckBox *FstatCheckBox;
    QCheckBox *allTracesCheckBox;
    QCheckBox *outPilotCheckBox;
    QCheckBox *outFreqCheckBox;
    QGroupBox *groupBox_3;
    QWidget *widget1;
    QHBoxLayout *horizontalLayout_11;
    QSpacerItem *horizontalSpacer_6;
    QVBoxLayout *verticalLayout_8;
    QLabel *label_15;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_16;
    QLabel *label_19;
    QLabel *label_20;
    QVBoxLayout *verticalLayout_7;
    QSpinBox *threadBox;
    QSpinBox *burninBox;
    QSpinBox *thinBox;
    QSpinBox *sampleBox;
    QSpinBox *nbpilotBox;
    QSpinBox *lengthpilotBox;
    QSpacerItem *horizontalSpacer_5;
    QGroupBox *groupBox_4;
    QWidget *widget2;
    QVBoxLayout *verticalLayout_16;
    QHBoxLayout *horizontalLayout_12;
    QVBoxLayout *verticalLayout_11;
    QLabel *lowerFisLabel;
    QLabel *upperFisLabel;
    QVBoxLayout *verticalLayout_10;
    QDoubleSpinBox *lowerFisBox;
    QDoubleSpinBox *upperFisBox;
    QSpacerItem *verticalSpacer_5;
    QHBoxLayout *horizontalLayout_14;
    QVBoxLayout *verticalLayout_14;
    QCheckBox *betaFisCheckBox;
    QHBoxLayout *horizontalLayout_13;
    QVBoxLayout *verticalLayout_13;
    QLabel *meanBetaLabel;
    QLabel *sdBetaLabel;
    QVBoxLayout *verticalLayout_12;
    QDoubleSpinBox *meanBetaBox;
    QDoubleSpinBox *sdBetaBox;
    QSpacerItem *verticalSpacer_4;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout_15;
    QLabel *label_26;
    QDoubleSpinBox *threshAFLPBox;
    QSpacerItem *verticalSpacer_3;
    QGroupBox *groupBox_5;
    QWidget *widget3;
    QHBoxLayout *horizontalLayout_7;
    QVBoxLayout *verticalLayout_4;
    QLabel *ULabel;
    QLabel *priorAlphaLabel;
    QLabel *prJumpLabel;
    QLabel *prPrefLabel;
    QVBoxLayout *verticalLayout_5;
    QSpacerItem *verticalSpacer_8;
    QSpinBox *UBox;
    QSpacerItem *verticalSpacer_7;
    QDoubleSpinBox *priorAlphaBox;
    QSpacerItem *verticalSpacer_2;
    QDoubleSpinBox *prJumpBox;
    QSpacerItem *verticalSpacer;
    QDoubleSpinBox *prPrefBox;
    QGroupBox *groupBox;
    QWidget *widget4;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QLabel *label_5;
    QLabel *envLabel;
    QLabel *label_3;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QLineEdit *inputEdit;
    QPushButton *browseInputButton;
    QHBoxLayout *horizontalLayout_4;
    QLineEdit *discEdit;
    QPushButton *browseDiscButton;
    QHBoxLayout *horizontalLayout_2;
    QLineEdit *envEdit;
    QPushButton *browseEnvButton;
    QHBoxLayout *horizontalLayout_3;
    QLineEdit *folderoutEdit;
    QPushButton *browseOutfolderButton;
    QSpacerItem *horizontalSpacer_2;
    QLabel *label_4;
    QLineEdit *nameoutEdit;
    QSpacerItem *horizontalSpacer_4;

    void setupUi(QWidget *GUI)
    {
        if (GUI->objectName().isEmpty())
            GUI->setObjectName(QStringLiteral("GUI"));
        GUI->resize(840, 596);
        QFont font;
        font.setFamily(QStringLiteral("Sans Serif"));
        GUI->setFont(font);
        GUI->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        displayBox = new QTextBrowser(GUI);
        displayBox->setObjectName(QStringLiteral("displayBox"));
        displayBox->setGeometry(QRect(10, 400, 821, 192));
        displayBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        layoutWidget = new QWidget(GUI);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(660, 370, 168, 25));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget);
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        startButton = new QPushButton(layoutWidget);
        startButton->setObjectName(QStringLiteral("startButton"));
        startButton->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_6->addWidget(startButton);

        stopButton = new QPushButton(layoutWidget);
        stopButton->setObjectName(QStringLiteral("stopButton"));
        stopButton->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_6->addWidget(stopButton);

        groupBox_2 = new QGroupBox(GUI);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(650, 10, 161, 161));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setWeight(75);
        groupBox_2->setFont(font1);
        widget = new QWidget(groupBox_2);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(10, 20, 144, 136));
        QFont font2;
        font2.setPointSize(9);
        font2.setBold(false);
        font2.setWeight(50);
        widget->setFont(font2);
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        SNPmatrixCheckBox = new QCheckBox(widget);
        SNPmatrixCheckBox->setObjectName(QStringLiteral("SNPmatrixCheckBox"));
        SNPmatrixCheckBox->setFont(font2);
        SNPmatrixCheckBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout->addWidget(SNPmatrixCheckBox);

        FstatCheckBox = new QCheckBox(widget);
        FstatCheckBox->setObjectName(QStringLiteral("FstatCheckBox"));
        FstatCheckBox->setFont(font2);
        FstatCheckBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout->addWidget(FstatCheckBox);

        allTracesCheckBox = new QCheckBox(widget);
        allTracesCheckBox->setObjectName(QStringLiteral("allTracesCheckBox"));
        allTracesCheckBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout->addWidget(allTracesCheckBox);

        outPilotCheckBox = new QCheckBox(widget);
        outPilotCheckBox->setObjectName(QStringLiteral("outPilotCheckBox"));
        outPilotCheckBox->setFont(font2);
        outPilotCheckBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout->addWidget(outPilotCheckBox);

        outFreqCheckBox = new QCheckBox(widget);
        outFreqCheckBox->setObjectName(QStringLiteral("outFreqCheckBox"));
        outFreqCheckBox->setFont(font2);
        outFreqCheckBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout->addWidget(outFreqCheckBox);

        groupBox_3 = new QGroupBox(GUI);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 180, 221, 211));
        groupBox_3->setFont(font1);
        widget1 = new QWidget(groupBox_3);
        widget1->setObjectName(QStringLiteral("widget1"));
        widget1->setGeometry(QRect(0, 29, 226, 178));
        horizontalLayout_11 = new QHBoxLayout(widget1);
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        horizontalLayout_11->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_6);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        label_15 = new QLabel(widget1);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setFont(font2);
        label_15->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_15->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_8->addWidget(label_15);

        label_17 = new QLabel(widget1);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setFont(font2);
        label_17->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_17->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_8->addWidget(label_17);

        label_18 = new QLabel(widget1);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setFont(font2);
        label_18->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_18->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_8->addWidget(label_18);

        label_16 = new QLabel(widget1);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setFont(font2);
        label_16->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_16->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_8->addWidget(label_16);

        label_19 = new QLabel(widget1);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setFont(font2);
        label_19->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_19->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_8->addWidget(label_19);

        label_20 = new QLabel(widget1);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setFont(font2);
        label_20->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_20->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_8->addWidget(label_20);


        horizontalLayout_11->addLayout(verticalLayout_8);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        threadBox = new QSpinBox(widget1);
        threadBox->setObjectName(QStringLiteral("threadBox"));
        threadBox->setFont(font2);
        threadBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout_7->addWidget(threadBox);

        burninBox = new QSpinBox(widget1);
        burninBox->setObjectName(QStringLiteral("burninBox"));
        burninBox->setFont(font2);
        burninBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        burninBox->setMaximum(10000000);
        burninBox->setValue(50000);

        verticalLayout_7->addWidget(burninBox);

        thinBox = new QSpinBox(widget1);
        thinBox->setObjectName(QStringLiteral("thinBox"));
        thinBox->setFont(font2);
        thinBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        thinBox->setMaximum(100000);
        thinBox->setValue(10);

        verticalLayout_7->addWidget(thinBox);

        sampleBox = new QSpinBox(widget1);
        sampleBox->setObjectName(QStringLiteral("sampleBox"));
        sampleBox->setFont(font2);
        sampleBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        sampleBox->setMaximum(1000000);
        sampleBox->setValue(5000);

        verticalLayout_7->addWidget(sampleBox);

        nbpilotBox = new QSpinBox(widget1);
        nbpilotBox->setObjectName(QStringLiteral("nbpilotBox"));
        nbpilotBox->setFont(font2);
        nbpilotBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        nbpilotBox->setMaximum(100);
        nbpilotBox->setValue(20);

        verticalLayout_7->addWidget(nbpilotBox);

        lengthpilotBox = new QSpinBox(widget1);
        lengthpilotBox->setObjectName(QStringLiteral("lengthpilotBox"));
        lengthpilotBox->setFont(font2);
        lengthpilotBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        lengthpilotBox->setMaximum(1000000);
        lengthpilotBox->setValue(2000);

        verticalLayout_7->addWidget(lengthpilotBox);


        horizontalLayout_11->addLayout(verticalLayout_7);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_5);

        groupBox_4 = new QGroupBox(GUI);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(240, 180, 341, 211));
        groupBox_4->setFont(font1);
        widget2 = new QWidget(groupBox_4);
        widget2->setObjectName(QStringLiteral("widget2"));
        widget2->setGeometry(QRect(10, 30, 326, 177));
        verticalLayout_16 = new QVBoxLayout(widget2);
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setContentsMargins(11, 11, 11, 11);
        verticalLayout_16->setObjectName(QStringLiteral("verticalLayout_16"));
        verticalLayout_16->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setObjectName(QStringLiteral("verticalLayout_11"));
        lowerFisLabel = new QLabel(widget2);
        lowerFisLabel->setObjectName(QStringLiteral("lowerFisLabel"));
        lowerFisLabel->setFont(font2);
        lowerFisLabel->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout_11->addWidget(lowerFisLabel);

        upperFisLabel = new QLabel(widget2);
        upperFisLabel->setObjectName(QStringLiteral("upperFisLabel"));
        upperFisLabel->setFont(font2);
        upperFisLabel->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout_11->addWidget(upperFisLabel);


        horizontalLayout_12->addLayout(verticalLayout_11);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        lowerFisBox = new QDoubleSpinBox(widget2);
        lowerFisBox->setObjectName(QStringLiteral("lowerFisBox"));
        lowerFisBox->setFont(font2);
        lowerFisBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        lowerFisBox->setDecimals(2);
        lowerFisBox->setMinimum(0);
        lowerFisBox->setMaximum(1);
        lowerFisBox->setSingleStep(0.01);
        lowerFisBox->setValue(0);

        verticalLayout_10->addWidget(lowerFisBox);

        upperFisBox = new QDoubleSpinBox(widget2);
        upperFisBox->setObjectName(QStringLiteral("upperFisBox"));
        upperFisBox->setFont(font2);
        upperFisBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        upperFisBox->setDecimals(2);
        upperFisBox->setMinimum(0);
        upperFisBox->setMaximum(1);
        upperFisBox->setSingleStep(0.01);
        upperFisBox->setValue(1);

        verticalLayout_10->addWidget(upperFisBox);


        horizontalLayout_12->addLayout(verticalLayout_10);


        verticalLayout_16->addLayout(horizontalLayout_12);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_16->addItem(verticalSpacer_5);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setObjectName(QStringLiteral("verticalLayout_14"));
        betaFisCheckBox = new QCheckBox(widget2);
        betaFisCheckBox->setObjectName(QStringLiteral("betaFisCheckBox"));
        betaFisCheckBox->setFont(font2);
        betaFisCheckBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout_14->addWidget(betaFisCheckBox);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setObjectName(QStringLiteral("verticalLayout_13"));
        meanBetaLabel = new QLabel(widget2);
        meanBetaLabel->setObjectName(QStringLiteral("meanBetaLabel"));
        meanBetaLabel->setEnabled(false);
        meanBetaLabel->setFont(font2);
        meanBetaLabel->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout_13->addWidget(meanBetaLabel);

        sdBetaLabel = new QLabel(widget2);
        sdBetaLabel->setObjectName(QStringLiteral("sdBetaLabel"));
        sdBetaLabel->setEnabled(false);
        sdBetaLabel->setFont(font2);
        sdBetaLabel->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        verticalLayout_13->addWidget(sdBetaLabel);


        horizontalLayout_13->addLayout(verticalLayout_13);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setObjectName(QStringLiteral("verticalLayout_12"));
        meanBetaBox = new QDoubleSpinBox(widget2);
        meanBetaBox->setObjectName(QStringLiteral("meanBetaBox"));
        meanBetaBox->setEnabled(false);
        meanBetaBox->setFont(font2);
        meanBetaBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        meanBetaBox->setDecimals(4);
        meanBetaBox->setMinimum(0);
        meanBetaBox->setMaximum(1);
        meanBetaBox->setSingleStep(0.001);
        meanBetaBox->setValue(0.05);

        verticalLayout_12->addWidget(meanBetaBox);

        sdBetaBox = new QDoubleSpinBox(widget2);
        sdBetaBox->setObjectName(QStringLiteral("sdBetaBox"));
        sdBetaBox->setEnabled(false);
        sdBetaBox->setFont(font2);
        sdBetaBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        sdBetaBox->setDecimals(4);
        sdBetaBox->setMinimum(0);
        sdBetaBox->setMaximum(1);
        sdBetaBox->setSingleStep(0.001);
        sdBetaBox->setValue(0.01);

        verticalLayout_12->addWidget(sdBetaBox);


        horizontalLayout_13->addLayout(verticalLayout_12);


        verticalLayout_14->addLayout(horizontalLayout_13);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_14->addItem(verticalSpacer_4);


        horizontalLayout_14->addLayout(verticalLayout_14);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_14->addItem(horizontalSpacer);

        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setObjectName(QStringLiteral("verticalLayout_15"));
        label_26 = new QLabel(widget2);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setFont(font2);
        label_26->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_26->setAlignment(Qt::AlignCenter);

        verticalLayout_15->addWidget(label_26);

        threshAFLPBox = new QDoubleSpinBox(widget2);
        threshAFLPBox->setObjectName(QStringLiteral("threshAFLPBox"));
        threshAFLPBox->setFont(font2);
        threshAFLPBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        threshAFLPBox->setDecimals(4);
        threshAFLPBox->setMinimum(0);
        threshAFLPBox->setMaximum(1);
        threshAFLPBox->setSingleStep(0.001);
        threshAFLPBox->setValue(0.1);

        verticalLayout_15->addWidget(threshAFLPBox);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_15->addItem(verticalSpacer_3);


        horizontalLayout_14->addLayout(verticalLayout_15);


        verticalLayout_16->addLayout(horizontalLayout_14);

        groupBox_5 = new QGroupBox(GUI);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(590, 180, 241, 181));
        groupBox_5->setFont(font1);
        widget3 = new QWidget(groupBox_5);
        widget3->setObjectName(QStringLiteral("widget3"));
        widget3->setGeometry(QRect(13, 30, 221, 141));
        horizontalLayout_7 = new QHBoxLayout(widget3);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        ULabel = new QLabel(widget3);
        ULabel->setObjectName(QStringLiteral("ULabel"));
        ULabel->setFont(font2);
        ULabel->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        ULabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_4->addWidget(ULabel);

        priorAlphaLabel = new QLabel(widget3);
        priorAlphaLabel->setObjectName(QStringLiteral("priorAlphaLabel"));
        priorAlphaLabel->setFont(font2);
        priorAlphaLabel->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        priorAlphaLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_4->addWidget(priorAlphaLabel);

        prJumpLabel = new QLabel(widget3);
        prJumpLabel->setObjectName(QStringLiteral("prJumpLabel"));
        prJumpLabel->setFont(font2);
        prJumpLabel->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        prJumpLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_4->addWidget(prJumpLabel);

        prPrefLabel = new QLabel(widget3);
        prPrefLabel->setObjectName(QStringLiteral("prPrefLabel"));
        prPrefLabel->setFont(font2);
        prPrefLabel->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        prPrefLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_4->addWidget(prPrefLabel);


        horizontalLayout_7->addLayout(verticalLayout_4);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_8);

        UBox = new QSpinBox(widget3);
        UBox->setObjectName(QStringLiteral("UBox"));
        UBox->setFont(font2);
        UBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        UBox->setMinimum(1);
        UBox->setMaximum(1000);
        UBox->setValue(10);

        verticalLayout_5->addWidget(UBox);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Preferred);

        verticalLayout_5->addItem(verticalSpacer_7);

        priorAlphaBox = new QDoubleSpinBox(widget3);
        priorAlphaBox->setObjectName(QStringLiteral("priorAlphaBox"));
        priorAlphaBox->setFont(font2);
        priorAlphaBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        priorAlphaBox->setDecimals(1);
        priorAlphaBox->setMinimum(-5);
        priorAlphaBox->setMaximum(5);
        priorAlphaBox->setSingleStep(0.1);
        priorAlphaBox->setValue(-1);

        verticalLayout_5->addWidget(priorAlphaBox);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Preferred);

        verticalLayout_5->addItem(verticalSpacer_2);

        prJumpBox = new QDoubleSpinBox(widget3);
        prJumpBox->setObjectName(QStringLiteral("prJumpBox"));
        prJumpBox->setFont(font2);
        prJumpBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        prJumpBox->setDecimals(2);
        prJumpBox->setMinimum(0);
        prJumpBox->setMaximum(1);
        prJumpBox->setSingleStep(0.05);
        prJumpBox->setValue(0.5);

        verticalLayout_5->addWidget(prJumpBox);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Preferred);

        verticalLayout_5->addItem(verticalSpacer);

        prPrefBox = new QDoubleSpinBox(widget3);
        prPrefBox->setObjectName(QStringLiteral("prPrefBox"));
        prPrefBox->setFont(font2);
        prPrefBox->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        prPrefBox->setDecimals(2);
        prPrefBox->setMinimum(0);
        prPrefBox->setMaximum(1);
        prPrefBox->setSingleStep(0.05);
        prPrefBox->setValue(0.1);

        verticalLayout_5->addWidget(prPrefBox);


        horizontalLayout_7->addLayout(verticalLayout_5);

        groupBox = new QGroupBox(GUI);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(12, 2, 609, 171));
        groupBox->setFont(font1);
        widget4 = new QWidget(groupBox);
        widget4->setObjectName(QStringLiteral("widget4"));
        widget4->setGeometry(QRect(0, 30, 609, 130));
        horizontalLayout_5 = new QHBoxLayout(widget4);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_3);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label = new QLabel(widget4);
        label->setObjectName(QStringLiteral("label"));
        label->setFont(font2);
        label->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_3->addWidget(label);

        label_5 = new QLabel(widget4);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setFont(font2);
        label_5->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_3->addWidget(label_5);

        envLabel = new QLabel(widget4);
        envLabel->setObjectName(QStringLiteral("envLabel"));
        envLabel->setFont(font2);
        envLabel->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        envLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_3->addWidget(envLabel);

        label_3 = new QLabel(widget4);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setFont(font2);
        label_3->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        label_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        verticalLayout_3->addWidget(label_3);


        horizontalLayout_5->addLayout(verticalLayout_3);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        inputEdit = new QLineEdit(widget4);
        inputEdit->setObjectName(QStringLiteral("inputEdit"));
        inputEdit->setFont(font2);
        inputEdit->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout->addWidget(inputEdit);

        browseInputButton = new QPushButton(widget4);
        browseInputButton->setObjectName(QStringLiteral("browseInputButton"));
        browseInputButton->setFont(font2);
        browseInputButton->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout->addWidget(browseInputButton);


        verticalLayout_2->addLayout(horizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        discEdit = new QLineEdit(widget4);
        discEdit->setObjectName(QStringLiteral("discEdit"));
        discEdit->setFont(font2);
        discEdit->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_4->addWidget(discEdit);

        browseDiscButton = new QPushButton(widget4);
        browseDiscButton->setObjectName(QStringLiteral("browseDiscButton"));
        browseDiscButton->setFont(font2);
        browseDiscButton->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_4->addWidget(browseDiscButton);


        verticalLayout_2->addLayout(horizontalLayout_4);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setSizeConstraint(QLayout::SetDefaultConstraint);
        envEdit = new QLineEdit(widget4);
        envEdit->setObjectName(QStringLiteral("envEdit"));
        envEdit->setFont(font2);
        envEdit->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_2->addWidget(envEdit);

        browseEnvButton = new QPushButton(widget4);
        browseEnvButton->setObjectName(QStringLiteral("browseEnvButton"));
        browseEnvButton->setFont(font2);
        browseEnvButton->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_2->addWidget(browseEnvButton);


        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setSizeConstraint(QLayout::SetDefaultConstraint);
        folderoutEdit = new QLineEdit(widget4);
        folderoutEdit->setObjectName(QStringLiteral("folderoutEdit"));
        folderoutEdit->setFont(font2);
        folderoutEdit->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_3->addWidget(folderoutEdit);

        browseOutfolderButton = new QPushButton(widget4);
        browseOutfolderButton->setObjectName(QStringLiteral("browseOutfolderButton"));
        browseOutfolderButton->setFont(font2);
        browseOutfolderButton->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_3->addWidget(browseOutfolderButton);

        horizontalSpacer_2 = new QSpacerItem(30, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);

        label_4 = new QLabel(widget4);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setFont(font2);
        label_4->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_3->addWidget(label_4);

        nameoutEdit = new QLineEdit(widget4);
        nameoutEdit->setObjectName(QStringLiteral("nameoutEdit"));
        nameoutEdit->setMaximumSize(QSize(100, 16777215));
        nameoutEdit->setFont(font2);
        nameoutEdit->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));

        horizontalLayout_3->addWidget(nameoutEdit);


        verticalLayout_2->addLayout(horizontalLayout_3);


        horizontalLayout_5->addLayout(verticalLayout_2);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Preferred, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_4);

        groupBox_5->raise();
        layoutWidget->raise();
        layoutWidget->raise();
        layoutWidget->raise();
        layoutWidget->raise();
        layoutWidget->raise();
        layoutWidget->raise();
        displayBox->raise();
        groupBox_2->raise();
        outPilotCheckBox->raise();
        outPilotCheckBox->raise();
        groupBox_3->raise();
        groupBox_4->raise();

        retranslateUi(GUI);

        QMetaObject::connectSlotsByName(GUI);
    } // setupUi

    void retranslateUi(QWidget *GUI)
    {
        GUI->setWindowTitle(QApplication::translate("GUI", "BayeScEnv GUI", 0));
#ifndef QT_NO_ACCESSIBILITY
        GUI->setAccessibleName(QApplication::translate("GUI", "BayeScEnv GUI", 0));
#endif // QT_NO_ACCESSIBILITY
        startButton->setText(QApplication::translate("GUI", "Start", 0));
        stopButton->setText(QApplication::translate("GUI", "Stop", 0));
        groupBox_2->setTitle(QApplication::translate("GUI", "Options", 0));
#ifndef QT_NO_TOOLTIP
        SNPmatrixCheckBox->setToolTip(QApplication::translate("GUI", "Should BayeScEnv be run in the SNP matrix mode?", 0));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        SNPmatrixCheckBox->setStatusTip(QString());
#endif // QT_NO_STATUSTIP
        SNPmatrixCheckBox->setText(QApplication::translate("GUI", "SNP matrix mode", 0));
#ifndef QT_NO_TOOLTIP
        FstatCheckBox->setToolTip(QApplication::translate("GUI", "Should BayeScEnv only estimate\n"
"F-stats?  (no selection)", 0));
#endif // QT_NO_TOOLTIP
        FstatCheckBox->setText(QApplication::translate("GUI", "F-stat mode", 0));
#ifndef QT_NO_TOOLTIP
        allTracesCheckBox->setToolTip(QApplication::translate("GUI", "Should BayeScEnv output the MCMC traces\n"
"of all parameters? (very large file!)", 0));
#endif // QT_NO_TOOLTIP
        allTracesCheckBox->setText(QApplication::translate("GUI", "All traces", 0));
#ifndef QT_NO_TOOLTIP
        outPilotCheckBox->setToolTip(QApplication::translate("GUI", "Should BayeScEnv output a file\n"
"containing the results of the pilot runs?", 0));
#endif // QT_NO_TOOLTIP
        outPilotCheckBox->setText(QApplication::translate("GUI", "Pilot results", 0));
#ifndef QT_NO_TOOLTIP
        outFreqCheckBox->setToolTip(QApplication::translate("GUI", "Should BayeScEnv output\n"
"the allele frequencies?", 0));
#endif // QT_NO_TOOLTIP
        outFreqCheckBox->setText(QApplication::translate("GUI", "Allele frequencies", 0));
        groupBox_3->setTitle(QApplication::translate("GUI", "Parameters of the MCMC chain", 0));
#ifndef QT_NO_TOOLTIP
        label_15->setToolTip(QApplication::translate("GUI", "Number of CPU threads used\n"
"for computation", 0));
#endif // QT_NO_TOOLTIP
        label_15->setText(QApplication::translate("GUI", "# Threads", 0));
#ifndef QT_NO_TOOLTIP
        label_17->setToolTip(QApplication::translate("GUI", "Length of the MCMC burn-in", 0));
#endif // QT_NO_TOOLTIP
        label_17->setText(QApplication::translate("GUI", "Burn-in", 0));
#ifndef QT_NO_TOOLTIP
        label_18->setToolTip(QApplication::translate("GUI", "Thinning interval", 0));
#endif // QT_NO_TOOLTIP
        label_18->setText(QApplication::translate("GUI", "Thinning", 0));
#ifndef QT_NO_TOOLTIP
        label_16->setToolTip(QApplication::translate("GUI", "Final sample size\n"
"(after thinning and without the burn-in)", 0));
#endif // QT_NO_TOOLTIP
        label_16->setText(QApplication::translate("GUI", "Final sample size", 0));
#ifndef QT_NO_TOOLTIP
        label_19->setToolTip(QApplication::translate("GUI", "Number of pilot runs", 0));
#endif // QT_NO_TOOLTIP
        label_19->setText(QApplication::translate("GUI", "# Pilot runs", 0));
#ifndef QT_NO_TOOLTIP
        label_20->setToolTip(QApplication::translate("GUI", "Length of each pilot run", 0));
#endif // QT_NO_TOOLTIP
        label_20->setText(QApplication::translate("GUI", "Length pilot runs", 0));
        groupBox_4->setTitle(QApplication::translate("GUI", "Parameters for dominant data", 0));
#ifndef QT_NO_TOOLTIP
        lowerFisLabel->setToolTip(QApplication::translate("GUI", "Minimal value for the Fis", 0));
#endif // QT_NO_TOOLTIP
        lowerFisLabel->setText(QApplication::translate("GUI", "Lower bound for uniform prior (Fis)", 0));
#ifndef QT_NO_TOOLTIP
        upperFisLabel->setToolTip(QApplication::translate("GUI", "Maximal value for the Fis", 0));
#endif // QT_NO_TOOLTIP
        upperFisLabel->setText(QApplication::translate("GUI", "Upper bound for uniform prior (Fis)", 0));
#ifndef QT_NO_TOOLTIP
        betaFisCheckBox->setToolTip(QApplication::translate("GUI", "Should BayeScEnv use a Beta prior\n"
"instead of the Uniform one?", 0));
#endif // QT_NO_TOOLTIP
        betaFisCheckBox->setText(QApplication::translate("GUI", "Beta prior for the Fis", 0));
#ifndef QT_NO_TOOLTIP
        meanBetaLabel->setToolTip(QApplication::translate("GUI", "Mean of the Beta prior", 0));
#endif // QT_NO_TOOLTIP
        meanBetaLabel->setText(QApplication::translate("GUI", "Mean beta", 0));
#ifndef QT_NO_TOOLTIP
        sdBetaLabel->setToolTip(QApplication::translate("GUI", "Standard deviation of the Beta prior", 0));
#endif // QT_NO_TOOLTIP
        sdBetaLabel->setText(QApplication::translate("GUI", "SD beta", 0));
#ifndef QT_NO_TOOLTIP
        label_26->setToolTip(QApplication::translate("GUI", "hreshold for the recessive genotype\n"
"as a fraction of maximum band intensity", 0));
#endif // QT_NO_TOOLTIP
        label_26->setText(QApplication::translate("GUI", "Recessive threshold\n"
"(AFLP band intensity)", 0));
        groupBox_5->setTitle(QApplication::translate("GUI", "General parameters", 0));
#ifndef QT_NO_TOOLTIP
        ULabel->setToolTip(QApplication::translate("GUI", "Maximal value for the parameter \"g\"\n"
"(slope for local adaptation)", 0));
#endif // QT_NO_TOOLTIP
        ULabel->setText(QApplication::translate("GUI", "Upper bound for g", 0));
#ifndef QT_NO_TOOLTIP
        priorAlphaLabel->setToolTip(QApplication::translate("GUI", "Mean of the Normal prior for the alpha parameter", 0));
#endif // QT_NO_TOOLTIP
        priorAlphaLabel->setText(QApplication::translate("GUI", "Mean prior for alpha", 0));
#ifndef QT_NO_TOOLTIP
        prJumpLabel->setToolTip(QApplication::translate("GUI", "Prior probability (pi) of jumping\n"
"away from the neutral model", 0));
#endif // QT_NO_TOOLTIP
        prJumpLabel->setText(QApplication::translate("GUI", "Prior probability for\n"
"non-neutral models", 0));
#ifndef QT_NO_TOOLTIP
        prPrefLabel->setToolTip(QApplication::translate("GUI", "Prior preference (p) for the locus-specific model\n"
"(as opposed to the \"local adaptation\" model)", 0));
#endif // QT_NO_TOOLTIP
        prPrefLabel->setText(QApplication::translate("GUI", "Prior preference for the\n"
"locus-specific model", 0));
        groupBox->setTitle(QApplication::translate("GUI", "Input / Output", 0));
#ifndef QT_NO_TOOLTIP
        label->setToolTip(QApplication::translate("GUI", "Path to the input file (genotypic data)", 0));
#endif // QT_NO_TOOLTIP
        label->setText(QApplication::translate("GUI", "Input file", 0));
#ifndef QT_NO_TOOLTIP
        label_5->setToolTip(QApplication::translate("GUI", "Path to the file containing the\n"
"discarded loci", 0));
#endif // QT_NO_TOOLTIP
        label_5->setText(QApplication::translate("GUI", "Discarded loci file", 0));
#ifndef QT_NO_TOOLTIP
        envLabel->setToolTip(QApplication::translate("GUI", "Path to the file containing\n"
"the environmental data", 0));
#endif // QT_NO_TOOLTIP
        envLabel->setText(QApplication::translate("GUI", "Environment file", 0));
#ifndef QT_NO_TOOLTIP
        label_3->setToolTip(QApplication::translate("GUI", "Path to the folder which\n"
"will contain the output files", 0));
#endif // QT_NO_TOOLTIP
        label_3->setText(QApplication::translate("GUI", "Output folder", 0));
        browseInputButton->setText(QApplication::translate("GUI", "...", 0));
        browseDiscButton->setText(QApplication::translate("GUI", "...", 0));
        browseEnvButton->setText(QApplication::translate("GUI", "...", 0));
        browseOutfolderButton->setText(QApplication::translate("GUI", "...", 0));
#ifndef QT_NO_TOOLTIP
        label_4->setToolTip(QApplication::translate("GUI", "Prefix for the output filenames", 0));
#endif // QT_NO_TOOLTIP
        label_4->setText(QApplication::translate("GUI", "Output prefix", 0));
    } // retranslateUi

};

namespace Ui {
    class GUI: public Ui_GUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUI_H
