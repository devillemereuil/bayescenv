BayeScEnv
=========

BayeScEnv is a Fst-based, genome-scan method that uses environmental variables to detect local adaptation.
